<?php

return [
    'invalid_url' => 'The :attribute value must be a valid URL or URI path.',
];
