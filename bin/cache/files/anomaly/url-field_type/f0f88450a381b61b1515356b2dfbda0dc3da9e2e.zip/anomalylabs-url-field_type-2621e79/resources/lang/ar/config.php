<?php

return [
    'default_value' => [
        'label'        => 'القيمة الافتراضية',
        'instructions' => 'حدد القيمة الافتراضية.',
    ],
];
