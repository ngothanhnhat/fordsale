<?php

return [
    'default_value' => [
        'label'        => '预设值',
        'instructions' => '指定预设的值.',
    ],
];
