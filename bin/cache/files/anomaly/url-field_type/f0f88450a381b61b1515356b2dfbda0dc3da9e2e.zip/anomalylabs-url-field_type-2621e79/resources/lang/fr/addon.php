<?php

return [
    'name'        => 'URL',
    'description' => 'Type de champs pour une URL.',
];
