<?php

return [
    'title'        => 'URL',
    'name'         => 'URL字段类型',
    'description'  => '用于输入URL的字段类型.',
];
