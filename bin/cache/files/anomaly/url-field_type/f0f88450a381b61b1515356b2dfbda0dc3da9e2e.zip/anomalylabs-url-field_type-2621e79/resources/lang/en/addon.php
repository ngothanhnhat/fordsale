<?php

return [
    'title'        => 'URL',
    'name'         => 'URL Field Type',
    'description'  => 'A URL input field type.',
];
