<?php

return [
    'title'       => 'URL',
    'name'        => 'URL Mező Típus',
    'description' => 'URL bekérőmező típus.',
];