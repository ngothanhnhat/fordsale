<?php

return [
    'default_value' => [
        'label'    => 'Alapértelmezett Érték',
    'instructions' => 'Add meg az alapértelmezett értéket.',
    ],
];