# URL Field Type

*anomaly.field_type.url*

### A URL field type.

The URL field type provides a simple HTML input restricting input to URLs.
