<?php

return [
    'title'       => 'Standard Form',
    'name'        => 'Standard Form Extension',
    'description' => '',
];
