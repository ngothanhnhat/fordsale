<?php

return [
    'title'       => 'Icon',
    'name'        => 'Icon Field Type',
    'description' => 'An option icon field type.',
];
