<?php

return [
    'unset'       => 'Unset',
    'placeholder' => 'Choose an icon...',
];
