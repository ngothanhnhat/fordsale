# Icon Field Type

*anomaly.field_type.icon*

#### A dropdown field type.

The icon field type provides an HTML icon input.
